# TrampsWorld Events

A mobile-first regional motorsports event discovery platform for Arizona, California, Nevada, and New Mexico.

This repository began as a working snapshot of Fresno Events. It already contains a React/Vite front end, Cloudflare Worker API, Google Calendar integration, normalized event data, agenda and FullCalendar views, filters, event detail pages, sharing tools, and a contact handoff.

The current project goal is to convert that inherited application into an independent TrampsWorld product without rebuilding proven functionality.

Start with:

- `AGENTS.md`
- `docs/working-state.md`
- `docs/product.specification.md`
- `docs/technical-architecture.md`
- `docs/event-data-model.md`
- `docs/design-system.md`
- `docs/development-phases.md`

## Local development

1. Copy `.dev.vars.example` to `.dev.vars`.
2. Set the Google Calendar and contact environment values.
3. Keep `.dev.vars` local. It is intentionally ignored by Git.

Expected TrampsWorld environment names after the conversion phase:

- `GOOGLE_CALENDAR_ID`
- `GOOGLE_CALENDAR_API_KEY`
- `GOOGLE_CALENDAR_TIMEZONE`
- `TRAMPSWORLD_EVENTS_CONTACT_EMAIL`

Useful commands:

- `npm run test`
- `npm run typecheck`
- `npm run build`
- `npm run dev`

Do not deploy the cloned application until Fresno-specific branding, environment names, metadata, and routes have been reviewed.
